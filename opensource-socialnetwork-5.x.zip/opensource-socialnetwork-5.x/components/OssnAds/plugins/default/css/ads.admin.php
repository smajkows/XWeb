.ossn-ad-image {
  width:200px;
  height:200px;
}
.ossn-ads-form textarea {
	    resize: vertical;
}