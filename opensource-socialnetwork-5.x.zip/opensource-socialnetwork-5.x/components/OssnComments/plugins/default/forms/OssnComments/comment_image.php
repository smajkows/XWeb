<input type="file" name="file" style="display:none;" id="ossn-comment-image-file-<?php echo $params['object']; ?>"/>
<div class="image-data"></div>